Promotions One-Time Import Package

Contents
- PromotionHeaders.csv
- PromotionLines.csv

Recommended import method
1. Keep both CSV files inside this ZIP.
2. In Dynamics 365 / Dataverse import wizard, upload this ZIP as one import job.
3. Import headers and lines in the same job.
4. Map lookups as follows:
   - Promotion Header -> Buying Group lookup (meta_buyinggroup) should match by Buying Group Name.
   - Promotion Line -> Promotion Header lookup (meta_promotionheader) should match by Promotion Header Name.
5. Upload banner images manually in the UI after import.

Field rules
- meta_promotionstatus values: Draft, Upcoming, Active, Expired, Inactive
- meta_featured values: Yes or No
- Date format: yyyy-mm-dd
- meta_scanpercent accepts decimals (example 5.00)
- Do not include image/file columns in import.

Important
- Import this ZIP as a single job, but it still contains separate source files for parent and child tables.
- Header names must remain unchanged.
- Buying Group names must already exist in the target environment.
- Promotion Header names used in PromotionLines.csv must exactly match the imported header names.
